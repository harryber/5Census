# 5Census
Proximity Chat Boards for the Claremont Colleges


Instructions:

Open a terminal:
Compile all of the necessary classes:
javac Server.java
javac Client.java
javac Post.java
javac Board.java

Run the server:
java Server <portNumber>

Open a second terminal to run the client:
java Client <portNumber>